-- ═══════════════════════════════════════════════════════════════
-- Supabase SQL — Run in SQL Editor for missing tables
-- Only run CREATE IF NOT EXISTS so it's safe to re-run
-- ═══════════════════════════════════════════════════════════════

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_number TEXT UNIQUE NOT NULL,
  user_id UUID REFERENCES auth.users(id),
  buyer_email TEXT,
  shipping_address JSONB,
  items JSONB NOT NULL,
  subtotal NUMERIC(10,2) NOT NULL,
  shipping NUMERIC(10,2) DEFAULT 0,
  tax NUMERIC(10,2) DEFAULT 0,
  total NUMERIC(10,2) NOT NULL,
  platform_fee NUMERIC(10,2) DEFAULT 0,
  seller_payout NUMERIC(10,2) DEFAULT 0,
  status TEXT DEFAULT 'pending_payment',
  payment_method TEXT DEFAULT 'stripe',
  store_credit_applied NUMERIC(10,2) DEFAULT 0,
  stripe_session_id TEXT,
  stripe_payment_intent_id TEXT,
  hold_until TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Add stripe_customer_id to users if missing
ALTER TABLE users ADD COLUMN IF NOT EXISTS stripe_customer_id TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS subscription TEXT DEFAULT 'free';
ALTER TABLE users ADD COLUMN IF NOT EXISTS subscription_expires_at TIMESTAMPTZ;

-- AML review flags
CREATE TABLE IF NOT EXISTS aml_flags (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  total_redeemed_usd TEXT,
  reason TEXT,
  status TEXT DEFAULT 'pending_review',
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Transactions table (if not already exists)
CREATE TABLE IF NOT EXISTS transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  type TEXT NOT NULL,
  currency TEXT DEFAULT 'style_points',
  amount NUMERIC(12,2) NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);

-- Battles table
CREATE TABLE IF NOT EXISTS battles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  challenger_id UUID REFERENCES auth.users(id),
  opponent_id UUID,
  challenger_outfit JSONB,
  opponent_outfit JSONB,
  wager_amount INTEGER DEFAULT 0,
  status TEXT DEFAULT 'open',
  winner_id UUID,
  votes_challenger INTEGER DEFAULT 0,
  votes_opponent INTEGER DEFAULT 0,
  voting_ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_battles_status ON battles(status);

-- Battle votes
CREATE TABLE IF NOT EXISTS battle_votes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  battle_id UUID REFERENCES battles(id),
  voter_id UUID REFERENCES auth.users(id),
  voted_for UUID,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(battle_id, voter_id)
);

-- Posts / feed
CREATE TABLE IF NOT EXISTS posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  content TEXT,
  outfit JSONB,
  image_url TEXT,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_posts_user ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);

-- Post likes
CREATE TABLE IF NOT EXISTS post_likes (
  post_id UUID REFERENCES posts(id),
  user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (post_id, user_id)
);

-- Seller applications
CREATE TABLE IF NOT EXISTS seller_applications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  brand_name TEXT NOT NULL,
  brand_type TEXT,
  website TEXT,
  instagram TEXT,
  description TEXT,
  status TEXT DEFAULT 'pending',
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Products / listings
CREATE TABLE IF NOT EXISTS products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_id UUID REFERENCES auth.users(id),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  images TEXT[],
  category TEXT,
  sizes TEXT[],
  colors TEXT[],
  style_tags TEXT[],
  listing_status TEXT DEFAULT 'pending',
  is_final_sale BOOLEAN DEFAULT FALSE,
  inventory INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(listing_status);

-- Row Level Security (enable on all tables)
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE battles ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_applications ENABLE ROW LEVEL SECURITY;

-- RLS policies (service key bypasses these, but good for direct Supabase client access)
CREATE POLICY IF NOT EXISTS "Users see own orders" ON orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY IF NOT EXISTS "Users see own apps" ON seller_applications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY IF NOT EXISTS "Anyone can read approved products" ON products FOR SELECT USING (listing_status = 'approved');
CREATE POLICY IF NOT EXISTS "Anyone can read posts" ON posts FOR SELECT USING (true);
CREATE POLICY IF NOT EXISTS "Anyone can read open battles" ON battles FOR SELECT USING (true);
