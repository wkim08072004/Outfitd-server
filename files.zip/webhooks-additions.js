// ═══════════════════════════════════════════════════════════════
// webhooks-additions.js — Add these handlers to your existing webhooks.js
// These handle order payment completion from Stripe Checkout
// ═══════════════════════════════════════════════════════════════

// ADD to your existing switch(event.type) block in webhooks.js:

/*
case 'checkout.session.completed': {
  const session = event.data.object;
  
  // ── Subscription checkout (existing) ──
  if (session.mode === 'subscription') {
    // Your existing subscription handler
  }
  
  // ── Marketplace order checkout ──
  if (session.mode === 'payment' && session.metadata?.order_id) {
    const orderId = session.metadata.order_id;
    const orderNumber = session.metadata.order_number;
    const platformFee = parseFloat(session.metadata.platform_fee || '0');
    
    // Update order status
    await supabase
      .from('orders')
      .update({
        status: 'awaiting_fulfillment',
        stripe_payment_intent_id: session.payment_intent,
        updated_at: new Date().toISOString(),
        // Hold payout for chargeback window (60-90 days for apparel)
        hold_until: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000).toISOString(),
      })
      .eq('id', orderId);
    
    // Get order details for Style Points award
    const { data: order } = await supabase
      .from('orders')
      .select('*, users!orders_user_id_fkey(subscription)')
      .eq('id', orderId)
      .single();
    
    if (order) {
      // Award Style Points based on subscription tier
      const tier = order.users?.subscription || 'free';
      const earnRate = tier === 'legend' ? 0.10 : tier === 'insider' ? 0.07 : 0.05;
      const earnedPoints = Math.round(order.subtotal * earnRate * 100);
      
      if (earnedPoints > 0) {
        // Add to wallet
        const { data: wallet } = await supabase
          .from('wallets')
          .select('op_balance')
          .eq('user_id', order.user_id)
          .single();
        
        if (wallet) {
          await supabase
            .from('wallets')
            .update({ op_balance: (wallet.op_balance || 0) + earnedPoints })
            .eq('user_id', order.user_id);
        }
        
        // Log transaction
        await supabase.from('transactions').insert({
          user_id: order.user_id,
          type: 'purchase_reward',
          currency: 'style_points',
          amount: earnedPoints,
          description: `Order ${orderNumber}: +${earnedPoints} Style Points (${Math.round(earnRate * 100)}% on $${order.subtotal})`,
        });
      }
    }
    
    console.log(`[Order] ${orderNumber} payment confirmed — awaiting fulfillment`);
  }
  break;
}

// Also add: handle payment failures
case 'checkout.session.expired': {
  const session = event.data.object;
  if (session.metadata?.order_id) {
    await supabase
      .from('orders')
      .update({ status: 'payment_failed', updated_at: new Date().toISOString() })
      .eq('id', session.metadata.order_id);
    console.log(`[Order] ${session.metadata.order_number} checkout expired`);
  }
  break;
}
*/

// ═══════════════════════════════════════════════════════════════
// Supabase RPC function for atomic battle vote increment
// Run this in Supabase SQL Editor:
// ═══════════════════════════════════════════════════════════════
/*
CREATE OR REPLACE FUNCTION increment_battle_votes(battle_uuid UUID, vote_field TEXT)
RETURNS void AS $$
BEGIN
  IF vote_field = 'votes_challenger' THEN
    UPDATE battles SET votes_challenger = votes_challenger + 1 WHERE id = battle_uuid;
  ELSIF vote_field = 'votes_opponent' THEN
    UPDATE battles SET votes_opponent = votes_opponent + 1 WHERE id = battle_uuid;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
*/
