/**
 * Guest Session Limits Middleware
 * Outfitd, Inc. — Pre-launch Module
 *
 * Tracks guest (unauthenticated) users via a short-lived session cookie.
 * Limits: 30-minute session, 20 page views, no access to purchase/wager/social features.
 * After limits are hit, API returns 401 prompting frontend to show signup modal.
 */

const crypto = require("crypto");

// In-memory store for guest sessions (replace with Redis/Upstash in production)
const guestSessions = new Map();

// Cleanup expired sessions every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [id, session] of guestSessions) {
    if (now - session.createdAt > 30 * 60 * 1000) {
      guestSessions.delete(id);
    }
  }
}, 10 * 60 * 1000);

// --- Configuration ---
const GUEST_CONFIG = {
  sessionDurationMs: 30 * 60 * 1000, // 30 minutes
  maxPageViews: 20,
  cookieName: "outfitd_guest",
  cookieMaxAge: 30 * 60 * 1000,
};

// Routes that guests can NEVER access (require auth always)
const BLOCKED_ROUTES = [
  "/api/orders",
  "/api/wallet",
  "/api/wager",
  "/api/battles/create",
  "/api/battles/accept",
  "/api/posts/create",
  "/api/posts/like",
  "/api/posts/comment",
  "/api/seller",
  "/api/referral",
  "/api/redeem",
  "/api/subscriptions",
  "/api/settings",
];

// Routes that guests CAN access (browsing only)
const ALLOWED_ROUTES = [
  "/api/health",
  "/api/auth/login",
  "/api/auth/register",
  "/api/auth/google",
  "/api/auth/apple",
  "/api/auth/verify",
  "/api/products",
  "/api/leaderboard/current",
  "/api/battles/feed",
];

/**
 * Middleware: Track and limit guest sessions
 */
function guestSessionMiddleware(req, res, next) {
  // If user is authenticated (has valid JWT), skip guest logic entirely
  if (req.user) {
    return next();
  }

  // Auth routes are always allowed
  if (req.path.startsWith("/api/auth/")) {
    return next();
  }

  // Health check always allowed
  if (req.path === "/api/health") {
    return next();
  }

  // Check if route is blocked for guests
  const isBlocked = BLOCKED_ROUTES.some((route) => req.path.startsWith(route));
  if (isBlocked) {
    return res.status(401).json({
      error: "Authentication required",
      code: "GUEST_BLOCKED_ROUTE",
      message: "Please create an account or log in to access this feature.",
    });
  }

  // Get or create guest session
  let guestId = req.cookies?.[GUEST_CONFIG.cookieName];
  let session;

  if (guestId && guestSessions.has(guestId)) {
    session = guestSessions.get(guestId);
  } else {
    // Create new guest session
    guestId = crypto.randomUUID();
    session = {
      id: guestId,
      createdAt: Date.now(),
      pageViews: 0,
      ip: req.ip,
    };
    guestSessions.set(guestId, session);
    res.cookie(GUEST_CONFIG.cookieName, guestId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: GUEST_CONFIG.cookieMaxAge,
    });
  }

  // Check session expiration
  const elapsed = Date.now() - session.createdAt;
  if (elapsed > GUEST_CONFIG.sessionDurationMs) {
    guestSessions.delete(guestId);
    res.clearCookie(GUEST_CONFIG.cookieName);
    return res.status(401).json({
      error: "Guest session expired",
      code: "GUEST_SESSION_EXPIRED",
      message:
        "Your browsing session has expired. Create an account to continue.",
    });
  }

  // Increment and check page views
  session.pageViews++;
  if (session.pageViews > GUEST_CONFIG.maxPageViews) {
    return res.status(401).json({
      error: "Guest limit reached",
      code: "GUEST_VIEW_LIMIT",
      message:
        "You've reached the browsing limit. Create a free account to continue exploring.",
      viewsUsed: session.pageViews,
      maxViews: GUEST_CONFIG.maxPageViews,
    });
  }

  // Attach guest info to request for logging
  req.guest = {
    id: guestId,
    pageViews: session.pageViews,
    remainingViews: GUEST_CONFIG.maxPageViews - session.pageViews,
    minutesRemaining: Math.ceil(
      (GUEST_CONFIG.sessionDurationMs - elapsed) / 60000
    ),
  };

  next();
}

/**
 * Helper: Get guest session stats (for admin/debugging)
 */
function getGuestSessionStats() {
  return {
    activeSessions: guestSessions.size,
    sessions: Array.from(guestSessions.values()).map((s) => ({
      id: s.id.substring(0, 8) + "...",
      pageViews: s.pageViews,
      ageMinutes: Math.round((Date.now() - s.createdAt) / 60000),
    })),
  };
}

module.exports = { guestSessionMiddleware, getGuestSessionStats, GUEST_CONFIG };
