-- ============================================================================
-- Outfitd Pre-Launch: Database Migrations
-- Run these in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ============================================================================

-- 1. Payouts table (for PayPal Store Credit redemption)
CREATE TABLE IF NOT EXISTS payouts (
  id TEXT PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  amount_usd DECIMAL(10,2) NOT NULL,
  store_credits_redeemed INTEGER NOT NULL,
  paypal_email TEXT NOT NULL,
  paypal_batch_id TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE payouts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own payouts" ON payouts
  FOR SELECT USING (auth.uid() = user_id);

CREATE INDEX idx_payouts_user ON payouts(user_id);
CREATE INDEX idx_payouts_status ON payouts(status);
CREATE INDEX idx_payouts_created ON payouts(created_at);

-- 2. Add payout fields to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS store_credits INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS kyc_verified BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_payout_at TIMESTAMPTZ;

-- 3. KYC submissions table
CREATE TABLE IF NOT EXISTS kyc_submissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  legal_first_name TEXT NOT NULL,
  legal_last_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  address_line1 TEXT NOT NULL,
  address_line2 TEXT,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  zip TEXT NOT NULL,
  country TEXT DEFAULT 'US',
  id_document_url TEXT NOT NULL,
  id_document_type TEXT NOT NULL CHECK (id_document_type IN ('drivers_license', 'passport', 'state_id')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  rejection_reason TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE kyc_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own KYC" ON kyc_submissions
  FOR SELECT USING (auth.uid() = user_id);

CREATE INDEX idx_kyc_user ON kyc_submissions(user_id);
CREATE INDEX idx_kyc_status ON kyc_submissions(status);

-- 4. Content moderation queue (for images when CSAM scan is skipped)
CREATE TABLE IF NOT EXISTS content_moderation_queue (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  file_hash TEXT NOT NULL,
  file_size INTEGER,
  file_type TEXT,
  scan_skip_reason TEXT,
  status TEXT DEFAULT 'pending_review' CHECK (status IN ('pending_review', 'approved', 'rejected')),
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE content_moderation_queue ENABLE ROW LEVEL SECURITY;
-- No user access — admin only via service role key

CREATE INDEX idx_modqueue_status ON content_moderation_queue(status);

-- 5. CSAM incidents table (NEVER delete records — legal requirement)
CREATE TABLE IF NOT EXISTS csam_incidents (
  id UUID PRIMARY KEY,
  user_id UUID,
  quarantine_path TEXT NOT NULL,
  file_hash TEXT NOT NULL,
  file_size INTEGER,
  file_type TEXT,
  original_filename TEXT,
  photodna_tracking_id TEXT,
  ip_address TEXT,
  user_agent TEXT,
  request_path TEXT,
  reported_to_ncmec BOOLEAN DEFAULT false,
  ncmec_report_id TEXT,
  reported_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE csam_incidents ENABLE ROW LEVEL SECURITY;
-- No user access — admin only via service role key

-- 6. Create Supabase Storage buckets (run these separately if needed)
-- In Supabase Dashboard → Storage → New Bucket:
--   Name: kyc-documents        | Private (no public access)
--   Name: quarantined-content  | Private (no public access)

-- ============================================================================
-- DONE. Verify by running: SELECT tablename FROM pg_tables WHERE schemaname = 'public';
-- ============================================================================
