/**
 * Seller KYC (Know Your Customer) Route
 * Outfitd, Inc. — Pre-launch Module
 *
 * Handles identity verification for marketplace sellers before they can:
 *   - List items for sale
 *   - Receive payouts
 *   - Participate in wagers with Store Credits
 *
 * Approach: Manual KYC via document upload + admin review.
 * This avoids expensive third-party KYC providers at launch.
 * Upgrade path: Integrate Stripe Identity or Persona.com later.
 *
 * Flow:
 *   1. Seller submits KYC form (legal name, DOB, address, ID photo)
 *   2. Data stored in Supabase with ID image in Supabase Storage (private bucket)
 *   3. Admin reviews via admin dashboard
 *   4. Admin approves or rejects with reason
 *   5. Seller is notified and status updated
 *
 * Required Supabase setup:
 *   - Table: kyc_submissions (see schema below)
 *   - Storage bucket: "kyc-documents" (private, no public access)
 *
 * SQL for kyc_submissions table:
 *   CREATE TABLE kyc_submissions (
 *     id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
 *     user_id UUID REFERENCES auth.users(id) NOT NULL,
 *     legal_first_name TEXT NOT NULL,
 *     legal_last_name TEXT NOT NULL,
 *     date_of_birth DATE NOT NULL,
 *     address_line1 TEXT NOT NULL,
 *     address_line2 TEXT,
 *     city TEXT NOT NULL,
 *     state TEXT NOT NULL,
 *     zip TEXT NOT NULL,
 *     country TEXT DEFAULT 'US',
 *     id_document_url TEXT NOT NULL,
 *     id_document_type TEXT NOT NULL CHECK (id_document_type IN ('drivers_license', 'passport', 'state_id')),
 *     status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
 *     rejection_reason TEXT,
 *     reviewed_by TEXT,
 *     reviewed_at TIMESTAMPTZ,
 *     created_at TIMESTAMPTZ DEFAULT now(),
 *     updated_at TIMESTAMPTZ DEFAULT now()
 *   );
 *
 *   -- RLS: users can only read their own submissions
 *   ALTER TABLE kyc_submissions ENABLE ROW LEVEL SECURITY;
 *   CREATE POLICY "Users read own KYC" ON kyc_submissions
 *     FOR SELECT USING (auth.uid() = user_id);
 */

const express = require("express");
const crypto = require("crypto");
const router = express.Router();

// --- Validation Helpers ---
function validateAge(dateOfBirth) {
  const dob = new Date(dateOfBirth);
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return age >= 18;
}

function validateZip(zip) {
  return /^\d{5}(-\d{4})?$/.test(zip);
}

const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA",
  "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT",
  "VA","WA","WV","WI","WY","DC",
];

/**
 * POST /api/kyc/submit
 * Submit KYC verification documents
 *
 * Body (multipart/form-data):
 *   legalFirstName, legalLastName, dateOfBirth (YYYY-MM-DD),
 *   addressLine1, addressLine2, city, state, zip,
 *   idDocumentType (drivers_license|passport|state_id),
 *   idDocument (file: JPEG/PNG, max 10MB)
 */
router.post("/submit", async (req, res) => {
  const { supabase, logtail } = req.app.locals;
  const userId = req.user.id;

  try {
    // --- Check if user already has a pending or approved KYC ---
    const { data: existing } = await supabase
      .from("kyc_submissions")
      .select("id, status")
      .eq("user_id", userId)
      .in("status", ["pending", "approved"])
      .limit(1);

    if (existing && existing.length > 0) {
      if (existing[0].status === "approved") {
        return res.status(400).json({
          error: "Your identity has already been verified",
          code: "KYC_ALREADY_APPROVED",
        });
      }
      return res.status(400).json({
        error: "You already have a pending verification. Please wait for review.",
        code: "KYC_ALREADY_PENDING",
        submissionId: existing[0].id,
      });
    }

    // --- Validate fields ---
    const {
      legalFirstName, legalLastName, dateOfBirth,
      addressLine1, addressLine2, city, state, zip,
      idDocumentType,
    } = req.body;

    const errors = [];
    if (!legalFirstName?.trim()) errors.push("Legal first name is required");
    if (!legalLastName?.trim()) errors.push("Legal last name is required");
    if (!dateOfBirth) errors.push("Date of birth is required");
    if (dateOfBirth && !validateAge(dateOfBirth))
      errors.push("You must be at least 18 years old");
    if (!addressLine1?.trim()) errors.push("Address is required");
    if (!city?.trim()) errors.push("City is required");
    if (!state || !US_STATES.includes(state.toUpperCase()))
      errors.push("Valid US state is required");
    if (!zip || !validateZip(zip)) errors.push("Valid ZIP code is required");
    if (!["drivers_license", "passport", "state_id"].includes(idDocumentType))
      errors.push("Valid ID document type is required");

    if (errors.length > 0) {
      return res.status(400).json({ error: "Validation failed", details: errors });
    }

    // --- Handle ID document upload ---
    if (!req.file) {
      return res.status(400).json({
        error: "ID document photo is required",
        code: "MISSING_DOCUMENT",
      });
    }

    const file = req.file;
    const allowedTypes = ["image/jpeg", "image/png"];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!allowedTypes.includes(file.mimetype)) {
      return res
        .status(400)
        .json({ error: "ID document must be JPEG or PNG" });
    }
    if (file.size > maxSize) {
      return res
        .status(400)
        .json({ error: "ID document must be under 10MB" });
    }

    // Upload to Supabase Storage (private bucket)
    const fileExt = file.mimetype === "image/png" ? "png" : "jpg";
    const fileName = `${userId}/${crypto.randomUUID()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("kyc-documents")
      .upload(fileName, file.buffer, {
        contentType: file.mimetype,
        upsert: false,
      });

    if (uploadError) {
      logtail?.error("KYC document upload failed", {
        userId,
        error: uploadError.message,
      });
      return res
        .status(500)
        .json({ error: "Failed to upload ID document" });
    }

    // --- Create KYC submission ---
    const { data: submission, error: insertError } = await supabase
      .from("kyc_submissions")
      .insert({
        user_id: userId,
        legal_first_name: legalFirstName.trim(),
        legal_last_name: legalLastName.trim(),
        date_of_birth: dateOfBirth,
        address_line1: addressLine1.trim(),
        address_line2: addressLine2?.trim() || null,
        city: city.trim(),
        state: state.toUpperCase(),
        zip: zip.trim(),
        id_document_type: idDocumentType,
        id_document_url: fileName,
        status: "pending",
      })
      .select("id, status, created_at")
      .single();

    if (insertError) {
      logtail?.error("KYC submission insert failed", {
        userId,
        error: insertError.message,
      });
      return res
        .status(500)
        .json({ error: "Failed to submit verification" });
    }

    logtail?.info("KYC submission received", {
      userId,
      submissionId: submission.id,
    });

    return res.status(201).json({
      success: true,
      submissionId: submission.id,
      status: "pending",
      message:
        "Your identity verification has been submitted. You will be notified once reviewed (typically within 24-48 hours).",
    });
  } catch (err) {
    logtail?.error("KYC submit error", { userId, error: err.message });
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/kyc/status
 * Check current KYC verification status
 */
router.get("/status", async (req, res) => {
  const { supabase } = req.app.locals;
  const userId = req.user.id;

  const { data: submission, error } = await supabase
    .from("kyc_submissions")
    .select("id, status, rejection_reason, created_at, reviewed_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(1)
    .single();

  if (error || !submission) {
    return res.json({
      verified: false,
      status: "not_submitted",
      message: "Identity verification has not been submitted yet.",
    });
  }

  return res.json({
    verified: submission.status === "approved",
    status: submission.status,
    submissionId: submission.id,
    rejectionReason: submission.rejection_reason || null,
    submittedAt: submission.created_at,
    reviewedAt: submission.reviewed_at,
  });
});

// =============================================================================
// ADMIN ROUTES (protected by admin middleware)
// =============================================================================

/**
 * GET /api/kyc/admin/pending
 * List all pending KYC submissions (admin only)
 */
router.get("/admin/pending", async (req, res) => {
  const { supabase } = req.app.locals;

  const { data: submissions, error } = await supabase
    .from("kyc_submissions")
    .select(`
      id, user_id, legal_first_name, legal_last_name, date_of_birth,
      address_line1, address_line2, city, state, zip,
      id_document_type, id_document_url, status, created_at
    `)
    .eq("status", "pending")
    .order("created_at", { ascending: true });

  if (error) {
    return res.status(500).json({ error: "Failed to fetch submissions" });
  }

  // Generate signed URLs for ID documents (valid for 1 hour)
  const enriched = await Promise.all(
    (submissions || []).map(async (sub) => {
      const { data: signedUrl } = await supabase.storage
        .from("kyc-documents")
        .createSignedUrl(sub.id_document_url, 3600);

      return {
        ...sub,
        id_document_signed_url: signedUrl?.signedUrl || null,
      };
    })
  );

  return res.json({ submissions: enriched, count: enriched.length });
});

/**
 * POST /api/kyc/admin/review/:submissionId
 * Approve or reject a KYC submission (admin only)
 *
 * Body: { decision: "approved" | "rejected", rejectionReason?: string }
 */
router.post("/admin/review/:submissionId", async (req, res) => {
  const { supabase, logtail } = req.app.locals;
  const { submissionId } = req.params;
  const { decision, rejectionReason } = req.body;

  if (!["approved", "rejected"].includes(decision)) {
    return res
      .status(400)
      .json({ error: 'Decision must be "approved" or "rejected"' });
  }

  if (decision === "rejected" && !rejectionReason?.trim()) {
    return res
      .status(400)
      .json({ error: "Rejection reason is required" });
  }

  // Update submission
  const { data: submission, error: updateError } = await supabase
    .from("kyc_submissions")
    .update({
      status: decision,
      rejection_reason: decision === "rejected" ? rejectionReason.trim() : null,
      reviewed_by: req.user.id,
      reviewed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq("id", submissionId)
    .eq("status", "pending")
    .select("user_id")
    .single();

  if (updateError || !submission) {
    return res
      .status(404)
      .json({ error: "Submission not found or already reviewed" });
  }

  // If approved, update user record
  if (decision === "approved") {
    await supabase
      .from("users")
      .update({ kyc_verified: true })
      .eq("id", submission.user_id);
  }

  logtail?.info("KYC review completed", {
    submissionId,
    userId: submission.user_id,
    decision,
    reviewedBy: req.user.id,
  });

  return res.json({
    success: true,
    submissionId,
    decision,
    message: `KYC submission ${decision}`,
  });
});

module.exports = router;
