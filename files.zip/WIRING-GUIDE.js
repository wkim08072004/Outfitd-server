/**
 * ============================================================================
 * SERVER WIRING GUIDE — How to integrate all modules
 * ============================================================================
 *
 * In your main server.js / app.js file, add these in order:
 *
 * // --- 1. Sentry (MUST be first) ---
 * const Sentry = require("@sentry/node");
 * Sentry.init({
 *   dsn: process.env.SENTRY_DSN,
 *   environment: process.env.NODE_ENV || "development",
 *   tracesSampleRate: 0.2,
 * });
 *
 * // --- 2. Express + standard middleware ---
 * const express = require("express");
 * const cookieParser = require("cookie-parser");
 * const multer = require("multer");
 * const app = express();
 * app.use(express.json());
 * app.use(cookieParser());
 *
 * // --- 3. Logtail ---
 * const { Logtail } = require("@logtail/node");
 * const logtail = new Logtail(process.env.LOGTAIL_TOKEN);
 * app.locals.logtail = logtail;
 *
 * // --- 4. Supabase client ---
 * const { createClient } = require("@supabase/supabase-js");
 * const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
 * app.locals.supabase = supabase;
 *
 * // --- 5. Guest session middleware (before routes) ---
 * const { guestSessionMiddleware } = require("./middleware/guestSession");
 * app.use("/api", guestSessionMiddleware);
 *
 * // --- 6. Auth middleware (your existing JWT verification) ---
 * const { authMiddleware } = require("./middleware/auth");
 *
 * // --- 7. Routes ---
 * const redeemRouter = require("./routes/redeem");
 * const kycRouter = require("./routes/kyc");
 *
 * app.use("/api/redeem", authMiddleware, redeemRouter);
 * app.use("/api/kyc", authMiddleware, kycRouter);
 *
 * // --- 8. CSAM scanning on image upload routes ---
 * const upload = multer({ storage: multer.memoryStorage() });
 * const { csamScanMiddleware } = require("./middleware/csamScanning");
 *
 * // Example: product listing photo upload
 * app.post("/api/products/upload-image",
 *   authMiddleware,
 *   upload.single("image"),
 *   csamScanMiddleware,
 *   async (req, res) => {
 *     // Image is scanned — safe to store in Supabase Storage
 *   }
 * );
 *
 * // --- 9. Sentry error handler (MUST be after all routes) ---
 * Sentry.setupExpressErrorHandler(app);
 *
 * // --- 10. Start server ---
 * app.listen(process.env.PORT || 3001);
 *
 *
 * ============================================================================
 * RENDER ENVIRONMENT VARIABLES (add all of these)
 * ============================================================================
 *
 * SENTRY_DSN=https://5af469d40ec76b40532fb6406429f573@o4511181187514368.ingest.us.sentry.io/4511181207109632
 * LOGTAIL_TOKEN=chAt1a4QGmW729fKKA4t6BXc
 * PAYPAL_CLIENT_ID=<from PayPal Developer Dashboard>
 * PAYPAL_CLIENT_SECRET=<from PayPal Developer Dashboard>
 * PAYPAL_MODE=sandbox
 * PAYOUTS_ENABLED=false
 * CSAM_SCANNING_ENABLED=false
 * PHOTODNA_API_KEY=<apply at microsoft.com/photodna>
 *
 * (Plus your existing: SUPABASE_URL, SUPABASE_SERVICE_KEY, JWT_SECRET,
 *  STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, etc.)
 *
 *
 * ============================================================================
 * NPM PACKAGES TO INSTALL
 * ============================================================================
 *
 * npm install @sentry/node @logtail/node axios multer cookie-parser
 *
 *
 * ============================================================================
 * SUPABASE SETUP
 * ============================================================================
 *
 * 1. Run supabase-migrations.sql in SQL Editor
 * 2. Create Storage buckets:
 *    - kyc-documents (Private)
 *    - quarantined-content (Private)
 * 3. Verify tables exist in Table Editor
 *
 */
