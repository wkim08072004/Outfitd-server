/**
 * CSAM (Child Sexual Abuse Material) Scanning Middleware
 * Outfitd, Inc. — Pre-launch Module
 *
 * ALL user-uploaded images must be scanned before being made publicly visible.
 * This applies to: product listing photos, profile pictures, outfit photos,
 * battle submissions, and post images.
 *
 * Approach (phased):
 *
 * Phase 1 (Launch): PhotoDNA Cloud API via Microsoft
 *   - Industry standard, used by all major platforms
 *   - Free for qualifying companies
 *   - Apply at: https://www.microsoft.com/en-us/photodna/cloud-service
 *   - Hash-based matching against NCMEC database
 *   - Does NOT store or view images — only generates/compares hashes
 *
 * Phase 2 (Scale): Add Google Cloud Vision SafeSearch or AWS Rekognition
 *   as a secondary layer for broader content moderation (nudity, violence, etc.)
 *
 * Legal obligation:
 *   - 18 U.S.C. § 2258A requires reporting known CSAM to NCMEC (CyberTipline)
 *   - Failure to report is a federal crime
 *   - NCMEC CyberTipline: https://report.cybertip.org/
 *   - You MUST preserve the image + metadata for law enforcement
 *   - Do NOT delete flagged images — quarantine them
 *
 * Required env vars:
 *   PHOTODNA_API_KEY (from Microsoft PhotoDNA Cloud Service)
 *   CSAM_SCANNING_ENABLED (true|false)
 *
 * Required npm packages:
 *   npm install axios
 */

const axios = require("axios");
const crypto = require("crypto");

// --- Configuration ---
const CSAM_CONFIG = {
  photoDNAEndpoint:
    "https://api.microsoftmoderator.com/photodna/v1.0/Match",
  // If PhotoDNA is not yet approved, images go to moderation queue
  quarantineBucket: "quarantined-content",
  moderationQueueTable: "content_moderation_queue",
};

/**
 * Scan an image buffer against PhotoDNA
 * Returns: { isMatch: boolean, trackingId: string }
 */
async function scanWithPhotoDNA(imageBuffer) {
  if (process.env.CSAM_SCANNING_ENABLED !== "true") {
    // If scanning not yet enabled, flag for manual review
    return { isMatch: false, scanSkipped: true };
  }

  if (!process.env.PHOTODNA_API_KEY) {
    // No API key yet — queue for manual moderation
    return { isMatch: false, scanSkipped: true, reason: "no_api_key" };
  }

  try {
    const response = await axios.post(
      CSAM_CONFIG.photoDNAEndpoint,
      {
        DataRepresentation: "inline",
        Value: imageBuffer.toString("base64"),
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Ocp-Apim-Subscription-Key": process.env.PHOTODNA_API_KEY,
        },
        timeout: 30000,
      }
    );

    return {
      isMatch: response.data.IsMatch === true,
      trackingId: response.data.TrackingId,
      status: response.data.Status?.Code,
    };
  } catch (err) {
    // If PhotoDNA is down, DO NOT silently pass the image through.
    // Queue for manual review instead.
    return {
      isMatch: false,
      scanSkipped: true,
      reason: "api_error",
      error: err.message,
    };
  }
}

/**
 * Middleware: Scan uploaded images for CSAM before storage
 *
 * Usage in route:
 *   const multer = require("multer");
 *   const upload = multer({ storage: multer.memoryStorage() });
 *   const { csamScanMiddleware } = require("./middleware/csamScanning");
 *
 *   router.post("/upload", upload.single("image"), csamScanMiddleware, async (req, res) => {
 *     // Image has been scanned — safe to store
 *   });
 */
async function csamScanMiddleware(req, res, next) {
  const { supabase, logtail } = req.app.locals;

  // Skip if no file uploaded
  if (!req.file) {
    return next();
  }

  const file = req.file;
  const userId = req.user?.id || "anonymous";

  // Only scan image files
  const imageTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
  if (!imageTypes.includes(file.mimetype)) {
    return next();
  }

  try {
    const scanResult = await scanWithPhotoDNA(file.buffer);

    // --- CSAM MATCH DETECTED ---
    if (scanResult.isMatch) {
      // CRITICAL: This is a legal obligation path

      // 1. Quarantine the image (do NOT delete)
      const quarantineId = crypto.randomUUID();
      const quarantinePath = `${quarantineId}-${Date.now()}.bin`;

      await supabase.storage
        .from(CSAM_CONFIG.quarantineBucket)
        .upload(quarantinePath, file.buffer, {
          contentType: file.mimetype,
          upsert: false,
        });

      // 2. Log the incident with full metadata
      await supabase.from("csam_incidents").insert({
        id: quarantineId,
        user_id: userId,
        quarantine_path: quarantinePath,
        file_hash: crypto
          .createHash("sha256")
          .update(file.buffer)
          .digest("hex"),
        file_size: file.size,
        file_type: file.mimetype,
        original_filename: file.originalname,
        photodna_tracking_id: scanResult.trackingId,
        ip_address: req.ip,
        user_agent: req.get("user-agent"),
        request_path: req.originalUrl,
        reported_to_ncmec: false,
      });

      // 3. Immediately disable the user account
      await supabase.auth.admin.updateUserById(userId, { banned: true });

      // 4. Log for immediate admin attention
      logtail?.error("CSAM MATCH DETECTED — IMMEDIATE ACTION REQUIRED", {
        userId,
        quarantineId,
        trackingId: scanResult.trackingId,
        ip: req.ip,
        action: "User banned. Image quarantined. MUST report to NCMEC CyberTipline.",
      });

      // 5. Return generic error (do not reveal detection method)
      return res.status(400).json({
        error: "This image cannot be uploaded. Your account has been suspended.",
        code: "CONTENT_VIOLATION",
      });
    }

    // --- Scan was skipped (API not configured or down) ---
    if (scanResult.scanSkipped) {
      // Queue for manual moderation — image is NOT immediately visible
      const moderationId = crypto.randomUUID();

      await supabase.from(CSAM_CONFIG.moderationQueueTable).insert({
        id: moderationId,
        user_id: userId,
        file_hash: crypto
          .createHash("sha256")
          .update(file.buffer)
          .digest("hex"),
        file_size: file.size,
        file_type: file.mimetype,
        scan_skip_reason: scanResult.reason || "scanning_disabled",
        status: "pending_review",
      });

      // Attach moderation ID to request so the route can store it
      req.moderationId = moderationId;
      req.imageModerated = false; // Flag: image needs approval before going public

      logtail?.warn("Image queued for manual moderation (scan skipped)", {
        userId,
        moderationId,
        reason: scanResult.reason,
      });

      return next();
    }

    // --- Clean scan ---
    req.imageModerated = true; // Flag: image passed automated scan
    return next();
  } catch (err) {
    // On any error, DO NOT allow the upload to proceed unscanned
    logtail?.error("CSAM scan middleware error", {
      userId,
      error: err.message,
    });

    return res.status(500).json({
      error: "Image processing failed. Please try again.",
      code: "SCAN_ERROR",
    });
  }
}

/**
 * Admin route helper: Get all items pending moderation
 */
async function getPendingModeration(supabase) {
  const { data, error } = await supabase
    .from(CSAM_CONFIG.moderationQueueTable)
    .select("*")
    .eq("status", "pending_review")
    .order("created_at", { ascending: true });

  return { items: data || [], error };
}

/**
 * Admin route helper: Get all CSAM incidents (for NCMEC reporting)
 */
async function getCSAMIncidents(supabase) {
  const { data, error } = await supabase
    .from("csam_incidents")
    .select("*")
    .order("created_at", { ascending: false });

  return { incidents: data || [], error };
}

module.exports = {
  csamScanMiddleware,
  scanWithPhotoDNA,
  getPendingModeration,
  getCSAMIncidents,
  CSAM_CONFIG,
};
