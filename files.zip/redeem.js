/**
 * PayPal Payouts Route
 * Outfitd, Inc. — Pre-launch Module
 *
 * Handles Store Credit redemption via PayPal Payouts API.
 * Flow: User earns Store Credits → hits minimum threshold → requests redemption →
 * server validates balance from DB (not client) → creates PayPal payout → zeros balance.
 *
 * Required env vars:
 *   PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_MODE (sandbox|live),
 *   PAYOUTS_ENABLED (true|false)
 *
 * Required npm packages:
 *   npm install axios
 */

const express = require("express");
const axios = require("axios");
const router = express.Router();

// --- Configuration ---
const PAYOUT_CONFIG = {
  minimumRedemptionUSD: 10.0, // Minimum Store Credits value to redeem
  storeCreditsToUSD: 0.01, // 1 Store Credit = $0.01 (100 SC = $1.00)
  maxPayoutUSD: 500.0, // Maximum single payout
  dailyPayoutLimitUSD: 1000.0, // Maximum total payouts per day
  cooldownHours: 24, // Hours between redemption requests per user
};

// --- PayPal Auth ---
async function getPayPalAccessToken() {
  const baseURL =
    process.env.PAYPAL_MODE === "live"
      ? "https://api-m.paypal.com"
      : "https://api-m.sandbox.paypal.com";

  const response = await axios.post(
    `${baseURL}/v1/oauth2/token`,
    "grant_type=client_credentials",
    {
      auth: {
        username: process.env.PAYPAL_CLIENT_ID,
        password: process.env.PAYPAL_CLIENT_SECRET,
      },
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    }
  );

  return { token: response.data.access_token, baseURL };
}

// --- Payout Execution ---
async function executePayPalPayout({ recipientEmail, amountUSD, userId, payoutId }) {
  const { token, baseURL } = await getPayPalAccessToken();

  const response = await axios.post(
    `${baseURL}/v1/payments/payouts`,
    {
      sender_batch_header: {
        sender_batch_id: payoutId,
        email_subject: "Your Outfitd Store Credit Redemption",
        email_message:
          "You have received a payout from your Outfitd Store Credits.",
      },
      items: [
        {
          recipient_type: "EMAIL",
          amount: {
            value: amountUSD.toFixed(2),
            currency: "USD",
          },
          receiver: recipientEmail,
          note: `Outfitd Store Credit redemption for user ${userId}`,
          sender_item_id: `outfitd-${payoutId}`,
        },
      ],
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    }
  );

  return response.data;
}

/**
 * POST /api/redeem
 * Redeem Store Credits for PayPal payout
 *
 * Body: { paypalEmail: string }
 * Requires: authenticated user (req.user set by auth middleware)
 */
router.post("/", async (req, res) => {
  const { supabase, logtail } = req.app.locals;

  // Kill switch check
  if (process.env.PAYOUTS_ENABLED !== "true") {
    return res.status(503).json({
      error: "Payouts are temporarily disabled",
      code: "PAYOUTS_DISABLED",
    });
  }

  try {
    const userId = req.user.id;
    const { paypalEmail } = req.body;

    // --- Validation ---
    if (!paypalEmail || !paypalEmail.includes("@")) {
      return res
        .status(400)
        .json({ error: "Valid PayPal email is required" });
    }

    // --- Get user balance from DATABASE (never trust client) ---
    const { data: user, error: userError } = await supabase
      .from("users")
      .select("id, email, store_credits, kyc_verified, last_payout_at")
      .eq("id", userId)
      .single();

    if (userError || !user) {
      return res.status(404).json({ error: "User not found" });
    }

    // --- KYC Check ---
    if (!user.kyc_verified) {
      return res.status(403).json({
        error: "Identity verification required before redemption",
        code: "KYC_REQUIRED",
      });
    }

    // --- Cooldown Check ---
    if (user.last_payout_at) {
      const hoursSinceLastPayout =
        (Date.now() - new Date(user.last_payout_at).getTime()) / (1000 * 60 * 60);
      if (hoursSinceLastPayout < PAYOUT_CONFIG.cooldownHours) {
        const hoursRemaining = Math.ceil(
          PAYOUT_CONFIG.cooldownHours - hoursSinceLastPayout
        );
        return res.status(429).json({
          error: `Please wait ${hoursRemaining} hours before requesting another payout`,
          code: "PAYOUT_COOLDOWN",
        });
      }
    }

    // --- Balance Check ---
    const storeCredits = user.store_credits || 0;
    const amountUSD = storeCredits * PAYOUT_CONFIG.storeCreditsToUSD;

    if (amountUSD < PAYOUT_CONFIG.minimumRedemptionUSD) {
      return res.status(400).json({
        error: `Minimum redemption is $${PAYOUT_CONFIG.minimumRedemptionUSD.toFixed(2)}. Your balance: $${amountUSD.toFixed(2)}`,
        code: "BELOW_MINIMUM",
        currentBalanceUSD: amountUSD,
        minimumUSD: PAYOUT_CONFIG.minimumRedemptionUSD,
      });
    }

    if (amountUSD > PAYOUT_CONFIG.maxPayoutUSD) {
      return res.status(400).json({
        error: `Maximum single payout is $${PAYOUT_CONFIG.maxPayoutUSD.toFixed(2)}`,
        code: "EXCEEDS_MAXIMUM",
      });
    }

    // --- Daily Limit Check ---
    const today = new Date().toISOString().split("T")[0];
    const { data: todayPayouts } = await supabase
      .from("payouts")
      .select("amount_usd")
      .gte("created_at", `${today}T00:00:00Z`)
      .eq("status", "completed");

    const todayTotal = (todayPayouts || []).reduce(
      (sum, p) => sum + p.amount_usd,
      0
    );
    if (todayTotal + amountUSD > PAYOUT_CONFIG.dailyPayoutLimitUSD) {
      return res.status(429).json({
        error: "Daily payout limit reached. Please try again tomorrow.",
        code: "DAILY_LIMIT",
      });
    }

    // --- Create payout record (pending) ---
    const payoutId = `PO-${Date.now()}-${userId.substring(0, 8)}`;
    const { error: insertError } = await supabase.from("payouts").insert({
      id: payoutId,
      user_id: userId,
      amount_usd: amountUSD,
      store_credits_redeemed: storeCredits,
      paypal_email: paypalEmail,
      status: "pending",
    });

    if (insertError) {
      logtail?.error("Payout record creation failed", {
        userId,
        error: insertError.message,
      });
      return res.status(500).json({ error: "Failed to create payout record" });
    }

    // --- Zero out Store Credits BEFORE sending payout (prevents double-spend) ---
    const { error: deductError } = await supabase
      .from("users")
      .update({
        store_credits: 0,
        last_payout_at: new Date().toISOString(),
      })
      .eq("id", userId)
      .eq("store_credits", storeCredits); // Optimistic lock: only deduct if balance hasn't changed

    if (deductError) {
      // Rollback payout record
      await supabase
        .from("payouts")
        .update({ status: "failed", error_message: "Balance deduction failed" })
        .eq("id", payoutId);
      logtail?.error("Store credit deduction failed", {
        userId,
        error: deductError.message,
      });
      return res
        .status(500)
        .json({ error: "Failed to process redemption. Please try again." });
    }

    // --- Execute PayPal Payout ---
    try {
      const paypalResult = await executePayPalPayout({
        recipientEmail: paypalEmail,
        amountUSD,
        userId,
        payoutId,
      });

      // Update payout record with PayPal batch ID
      await supabase
        .from("payouts")
        .update({
          status: "completed",
          paypal_batch_id: paypalResult.batch_header?.payout_batch_id,
        })
        .eq("id", payoutId);

      logtail?.info("Payout completed", {
        userId,
        amountUSD,
        payoutId,
        paypalBatchId: paypalResult.batch_header?.payout_batch_id,
      });

      return res.json({
        success: true,
        payoutId,
        amountUSD,
        storeCreditsRedeemed: storeCredits,
        message: `$${amountUSD.toFixed(2)} sent to ${paypalEmail}`,
      });
    } catch (paypalError) {
      // PayPal failed — refund the Store Credits
      await supabase
        .from("users")
        .update({ store_credits: storeCredits })
        .eq("id", userId);

      await supabase
        .from("payouts")
        .update({
          status: "failed",
          error_message: paypalError.response?.data?.message || paypalError.message,
        })
        .eq("id", payoutId);

      logtail?.error("PayPal payout failed — credits refunded", {
        userId,
        amountUSD,
        error: paypalError.response?.data || paypalError.message,
      });

      return res.status(502).json({
        error: "Payout failed. Your Store Credits have been refunded.",
        code: "PAYPAL_ERROR",
      });
    }
  } catch (err) {
    logtail?.error("Payout route error", { error: err.message });
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/redeem/status/:payoutId
 * Check status of a payout
 */
router.get("/status/:payoutId", async (req, res) => {
  const { supabase } = req.app.locals;
  const userId = req.user.id;

  const { data: payout, error } = await supabase
    .from("payouts")
    .select("id, amount_usd, status, paypal_email, created_at")
    .eq("id", req.params.payoutId)
    .eq("user_id", userId)
    .single();

  if (error || !payout) {
    return res.status(404).json({ error: "Payout not found" });
  }

  return res.json(payout);
});

module.exports = router;
module.exports.PAYOUT_CONFIG = PAYOUT_CONFIG;
