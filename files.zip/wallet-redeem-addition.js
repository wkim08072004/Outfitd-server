// ═══════════════════════════════════════════════════════════════
// wallet-redeem.js — Add this route to your existing wallet.js
// Or merge into /Users/eshapatel/outfitd-server/routes/wallet.js
// ═══════════════════════════════════════════════════════════════

// ADD THIS ROUTE to your existing wallet.js router:

// POST /api/wallet/redeem
// Converts Style Points → Store Credits at 100:1 ratio
router.post('/redeem', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;
    const { amount } = req.body; // amount in Style Points (e.g. 5000)

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid redemption amount' });
    }

    // Get current balance from DB
    const { data: wallet, error: wErr } = await supabase
      .from('wallets')
      .select('op_balance, store_credits')
      .eq('user_id', userId)
      .single();

    if (wErr || !wallet) {
      return res.status(400).json({ error: 'Wallet not found' });
    }

    if (wallet.op_balance < amount) {
      return res.status(400).json({ error: 'Insufficient Style Points balance' });
    }

    // Get user's subscription tier for min redeem check
    const { data: user } = await supabase
      .from('users')
      .select('subscription')
      .eq('id', userId)
      .single();

    const tier = user?.subscription || 'free';
    const minRedeem = tier === 'legend' ? 2500 : tier === 'insider' ? 5000 : 10000;

    if (amount < minRedeem) {
      return res.status(400).json({ error: `Minimum ${minRedeem} Style Points required to redeem` });
    }

    // Convert: 100 Style Points = $1.00 Store Credit
    const dollarValue = Math.round((amount / 100) * 100) / 100;

    // Atomic update: deduct OP, add store credits
    const newOP = wallet.op_balance - amount;
    const newCredits = (wallet.store_credits || 0) + dollarValue;

    const { error: updateErr } = await supabase
      .from('wallets')
      .update({
        op_balance: newOP,
        store_credits: newCredits,
      })
      .eq('user_id', userId);

    if (updateErr) {
      return res.status(500).json({ error: 'Redemption failed' });
    }

    // Log the transaction
    await supabase.from('transactions').insert({
      user_id: userId,
      type: 'redeem',
      currency: 'style_points',
      amount: -amount,
      description: `Redeemed ${amount} Style Points for $${dollarValue.toFixed(2)} Store Credits`,
    });

    // AML flag if cumulative payouts approach $600
    const { data: totalRedeemed } = await supabase
      .from('transactions')
      .select('amount')
      .eq('user_id', userId)
      .eq('type', 'redeem');

    const cumulativeRedeemed = (totalRedeemed || []).reduce((sum, t) => sum + Math.abs(t.amount), 0);
    if (cumulativeRedeemed / 100 >= 600) {
      // Flag for AML review
      await supabase.from('aml_flags').insert({
        user_id: userId,
        total_redeemed_usd: (cumulativeRedeemed / 100).toFixed(2),
        reason: 'Cumulative redemptions >= $600 (1099-NEC threshold)',
        status: 'pending_review',
      });
      console.warn(`[AML] User ${userId} hit $600 redemption threshold`);
    }

    return res.json({
      new_balance: newOP,
      store_credits: newCredits,
      redeemed_points: amount,
      dollar_value: dollarValue,
    });
  } catch (err) {
    console.error('Wallet redeem error:', err);
    return res.status(500).json({ error: 'Redemption failed' });
  }
});
