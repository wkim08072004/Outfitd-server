# OUTFITD v40-5 — Backend Wiring Update
## What changed and how to deploy

---

## FRONTEND (outfitd_v40-5.html)

### Changes made:
1. **CSP header** — Added `https://outfitd-server.onrender.com` to `connect-src`
2. **subscribeTier()** — Now calls `POST /api/subscriptions/checkout` → Stripe Checkout redirect
3. **cancelSubscription()** — Now calls `GET /api/subscriptions/portal` → Stripe Customer Portal
4. **runAISuggest()** — SECURITY FIX: Was calling Anthropic API directly from browser. Now proxies through `POST /api/ai/suggest`
5. **submitMarketplaceOrder()** — Now calls `POST /api/orders/create` → Stripe Checkout for payment
6. **redeemCashOP()** — Now calls `POST /api/wallet/redeem` server-side
7. **issueChallenge()** — Now calls `POST /api/battles/create` (server-first, escrow deduction)
8. **acceptChallenge()** — Now calls `POST /api/battles/accept`
9. **castVote()** — Now calls `POST /api/battles/vote` (with optimistic UI + rollback)
10. **submitSellerApply()** — Now also calls `POST /api/seller/apply`
11. **submitPartnerApply()** — Now also calls `POST /api/seller/partner-apply`
12. **handleStripeReturn()** — New function handles `?order_success=`, `?subscription_success=` URL params

### Deploy frontend:
```bash
# Replace your current frontend file
cp outfitd_v40-5.html /path/to/your/frontend/index.html
# Push to GitHub → Render auto-deploys
git add . && git commit -m "v40-5: wire all features to backend API" && git push
```

---

## BACKEND — New/Updated Route Files

### 1. orders.js (NEW)
**Path:** `routes/orders.js`
**Endpoints:**
- `POST /api/orders/create` — Creates order + Stripe Checkout Session
- `GET /api/orders/history` — User's past orders
- `GET /api/orders/:id` — Single order detail

**Add to server.js:**
```js
app.use('/api/orders', require('./routes/orders'));
```

### 2. ai.js (REPLACE or UPDATE)
**Path:** `routes/ai.js`
**Endpoints:**
- `POST /api/ai/suggest` — Outfit suggestion proxy (sanitized, rate-limited)
- `POST /api/ai/search` — Shop search proxy

**Requires:** `npm install express-rate-limit`

### 3. subscriptions.js (REPLACE or UPDATE)
**Path:** `routes/subscriptions.js`
**Endpoints:**
- `POST /api/subscriptions/checkout` — Create Stripe Checkout Session for subscription
- `GET /api/subscriptions/portal` — Create Stripe Customer Portal session
- `GET /api/subscriptions/status` — Current subscription status

**New env var needed:** `STRIPE_LEGEND_PRICE_ID` (create Legend tier in Stripe Dashboard)

### 4. battles.js (REPLACE or UPDATE)
**Path:** `routes/battles.js`
**Endpoints:**
- `POST /api/battles/create` — Issue challenge (escrows wager)
- `POST /api/battles/accept` — Accept challenge
- `POST /api/battles/vote` — Cast vote (unique constraint)
- `GET /api/battles/active` — List open/active battles

### 5. seller.js (REPLACE or UPDATE)
**Path:** `routes/seller.js`
**Endpoints:**
- `POST /api/seller/apply` — Submit seller application
- `POST /api/seller/partner-apply` — Submit partner application
- `POST /api/seller/listings` — Create listing (seller-only)
- `GET /api/seller/listings` — Get seller's listings

### 6. wallet-redeem-addition.js (ADD TO existing wallet.js)
**Add route:** `POST /api/wallet/redeem`
- Converts Style Points → Store Credits at 100:1
- Includes AML $600 threshold flag

### 7. webhooks-additions.js (ADD TO existing webhooks.js)
- `checkout.session.completed` handler for marketplace orders
- `checkout.session.expired` handler for failed payments
- Awards Style Points on successful purchase

---

## DATABASE — Run in Supabase SQL Editor

**File:** `supabase-tables.sql`

Creates these tables (IF NOT EXISTS — safe to re-run):
- `orders` — marketplace orders
- `aml_flags` — AML review queue
- `transactions` — wallet transaction log
- `battles` — style battles
- `battle_votes` — unique vote records
- `posts` — feed posts
- `post_likes` — post like records
- `seller_applications` — seller/partner apps
- `products` — marketplace listings

Also adds columns to `users`:
- `stripe_customer_id`
- `subscription`
- `subscription_expires_at`

Also creates the `increment_battle_votes` RPC function.

Also enables Row Level Security on all new tables.

---

## DEPLOY CHECKLIST

```
[ ] 1. Run supabase-tables.sql in Supabase SQL Editor
[ ] 2. Run the increment_battle_votes function SQL (in webhooks-additions.js)
[ ] 3. Copy backend route files to outfitd-server/routes/
[ ] 4. Add route mounts to server.js (see above)
[ ] 5. npm install express-rate-limit (if not already installed)
[ ] 6. Add STRIPE_LEGEND_PRICE_ID to Render env vars (create price in Stripe first)
[ ] 7. Add checkout.session.completed handler to webhooks.js
[ ] 8. Push backend to GitHub → Render deploys
[ ] 9. Replace frontend HTML with v40-5 → push → Render deploys
[ ] 10. Test: signup → subscribe → shop → checkout → battle → vote
```

---

## CHECKLIST ITEMS THIS COVERS

### Completed by this update:
- [x] Stripe marketplace payments (Payment Intents via Checkout)
- [x] Stripe Customer Portal (wired in frontend)
- [x] Store Stripe customer ID per user (in orders.js + subscriptions.js)
- [x] 15% platform fee enforcement server-side (orders.js)
- [x] Seller role check middleware (seller.js requireSeller)
- [x] Product listing moderation (pending status by default)
- [x] Final-sale toggle server-side (products table)
- [x] AML review thresholds (wallet-redeem-addition.js)
- [x] Frontend rewire Pass 2 (battles, orders, seller, AI)

### Still remaining after this:
- [ ] Stripe Radar rules (Stripe Dashboard config)
- [ ] PayPal Payouts integration (cash back → PayPal)
- [ ] PayPal email verification flow
- [ ] Seller KYC via Stripe Connect
- [ ] Payout hold period enforcement (DB field added, needs cron)
- [ ] Return/refund flow via Stripe Refunds API
- [ ] CSAM image scanning (Azure Content Moderator)
- [ ] Guest session limits server-side (Redis TTL)
- [ ] Sentry, Logtail, UptimeRobot setup
- [ ] Incident Response Plan document
- [ ] Git history audit for secrets
