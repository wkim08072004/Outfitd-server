# Outfitd Pre-Launch Checklist — Handoff Document
## April 7, 2026

---

## PROJECT OVERVIEW

- **Company:** Outfitd, Inc. (California LLC)
- **Product:** Streetwear social commerce platform (marketplace, outfit builder, style battles, rewards)
- **Frontend:** Single-file HTML/CSS/JS deployed on Render
  - URL: https://outfitd.co
  - Repo: github.com/wkim08072004 (outfitd-frontend)
  - Local: /Users/eshapatel/outfitd-frontend/
  - Contains: index.html, package.json, node_modules
- **Backend:** Node.js/Express deployed on Render
  - URL: https://outfitd-server.onrender.com
  - Repo: github.com/wkim08072004/Outfitd-server
  - Local: /Users/eshapatel/outfitd-server/
  - Health check: https://outfitd-server.onrender.com/health → {"status":"ok"}
- **Database:** Supabase (PostgreSQL + Auth + Storage)
- **Domain:** outfitd.co (Namecheap, DNS via Cloudflare)
- **Payments:** Stripe (subscriptions + marketplace) + PayPal (payouts)

---

## BACKEND STRUCTURE (outfitd-server)

```
server.js              ← Main entry point (Express app)
routes/
  admin.js             ← Admin panel routes
  ai.js                ← AI proxy routes
  auth.js              ← Authentication (register, login, Google OAuth)
  battles.js           ← Style battles / Prestige Arena
  kyc.js               ← KYC identity verification (NEW)
  leaderboard.js       ← Leaderboard + distribution
  orders.js            ← Marketplace orders
  posts.js             ← Social posts
  redeem.js            ← PayPal Store Credit redemption (NEW)
  seller.js            ← Seller dashboard
  subscriptions.js     ← Stripe subscription tiers
  tournaments.js       ← Tournament system
  user.js              ← User profile
  verify.js            ← Email verification
  wallet.js            ← Wallet / Store Credits
  webhooks.js          ← Stripe webhooks
middleware/
  guestSession.js      ← Guest session limits (NEW)
  csamScanning.js      ← CSAM image scanning (NEW)
```

## server.js WIRING ORDER
1. Sentry init (must be first)
2. dotenv, express, helmet, cors, rate-limit, cookie-parser
3. Logtail + Supabase client (shared via app.locals)
4. Security headers (helmet)
5. CORS (origin: FRONTEND_URL)
6. Rate limiting (100/15min general, 20/15min auth)
7. Cookie parser
8. Webhooks route (before JSON parser — needs raw body)
9. JSON parser (2mb limit)
10. Guest session middleware
11. All routes
12. Health check endpoint
13. Sentry error handler
14. app.listen

---

## RENDER ENVIRONMENT VARIABLES (Outfitd-server)

All set and deployed:
- ANTHROPIC_API_KEY
- CSAM_SCANNING_ENABLED=false
- FRONTEND_URL=https://outfitd.co
- GOOGLE_CLIENT_ID
- GOOGLE_CLIENT_SECRET
- JWT_REFRESH_SECRET
- JWT_SECRET
- LOGTAIL_TOKEN=chAt1a4QGmW729fKKA4t6BXc
- NODE_ENV=production
- PAYPAL_MODE=sandbox
- PAYOUTS_ENABLED=false
- SENTRY_DSN=https://5af469d40ec76b40532fb6406429f573@o4511181187514368.ingest.us.sentry.io/4511181207109632
- STRIPE_INSIDER_PRICE_ID
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- SUPABASE_SERVICE_KEY
- SUPABASE_URL

---

## SUPABASE TABLES (all created)

Core tables (created earlier):
- users, products, orders, battles, posts, etc.

New tables (created today April 7):
- **payouts** — PayPal payout records (id, user_id, amount_usd, store_credits_redeemed, paypal_email, status)
- **kyc_submissions** — KYC identity verification (legal name, DOB, address, ID document, status)
- **content_moderation_queue** — Images pending manual review when CSAM scan is skipped
- **csam_incidents** — CSAM detection records (NEVER delete — legal requirement)

New columns on users table:
- store_credits (INTEGER, default 0)
- kyc_verified (BOOLEAN, default false)
- last_payout_at (TIMESTAMPTZ)

## SUPABASE STORAGE BUCKETS (all created)

- **kyc-documents** (Private) — Seller ID documents
- **quarantined-content** (Private) — Quarantined CSAM-flagged images

---

## THIRD-PARTY SERVICES STATUS

| Service | Status | Account |
|---------|--------|---------|
| Sentry (error tracking) | ✅ Set up | outfitd-inc.sentry.io — 2 projects: outfitd-frontend, outfitd-backend |
| Logtail/Better Stack (logging) | ✅ Set up | Source: "Outfitd Backend", token configured |
| UptimeRobot (monitoring) | ✅ Set up | 2 monitors active: Outfitd Frontend (100%), Outfitd API Health (100%) |
| Stripe | ✅ Set up | Test mode, webhook configured |
| PayPal Developer | ✅ Set up | Sandbox mode, payouts disabled |
| Cloudflare (DNS) | ✅ Set up | DNS for outfitd.co |
| Render (hosting) | ✅ Set up | Frontend + Backend deployed |
| Supabase (database) | ✅ Set up | All tables + storage buckets |
| Microsoft PhotoDNA | ⬜ Pending | Need to apply at microsoft.com/photodna (free, few days) |
| Google OAuth | ✅ Credentials set | GOOGLE_CLIENT_ID + SECRET in Render |
| Apple Sign In | ⬜ Not yet | Need Apple Developer credentials |
| Anthropic API | ✅ Set up | API key in Render |

---

## COMPLETED CHECKLIST ITEMS

### Phase 1-6 (completed in prior sessions)
- ✅ LLC formation (bizfile.sos.ca.gov)
- ✅ Privacy Policy + Terms of Service (Termly)
- ✅ Seller Agreement v3.3
- ✅ Domain registration (outfitd.co)
- ✅ Frontend deployment to Render
- ✅ Custom domain + Cloudflare DNS
- ✅ GitHub repos set up
- ✅ Stripe account + webhook
- ✅ PayPal Developer account
- ✅ Upstash Redis account
- ✅ NDA workflow (Cooley GO + Dropbox Sign)
- ✅ Copyright registration guide
- ✅ Legal Compliance Brief v3 (1v1 wager feature)
- ✅ DMCA agent registration guide
- ✅ 18+ age minimum, arbitration-first, 30-day return window
- ✅ Store Credits rebranding (from "cash back")
- ✅ Frontend v40+ with all features

### Phase 7: Monitoring & Incident Response (completed today)
- ✅ Set up Sentry for error tracking (frontend + backend projects)
- ✅ Set up server-side logging with Logtail
- ✅ Set up uptime monitoring with UptimeRobot
- ✅ Write Incident Response Plan document

### Phase 8: Pre-Launch Security Audit — Infrastructure (completed today)
- ✅ npm audit (0 vulnerabilities)
- ✅ Verify no API keys in frontend bundle (clean)
- ✅ Guest session limits (deployed)
- ✅ PayPal Payouts route (deployed, disabled)
- ✅ Seller KYC route (deployed)
- ✅ CSAM scanning middleware (deployed, disabled until PhotoDNA approved)
- ✅ Supabase migrations (all new tables created)
- ✅ Supabase Storage buckets (kyc-documents, quarantined-content)
- ✅ Backend fully wired with Sentry + Logtail + guest sessions + new routes
- ✅ FRONTEND_URL env var set on Render
- ✅ Health endpoint responding

---

## REMAINING CHECKLIST ITEMS (Phase 8 Testing)

These are manual end-to-end tests. A detailed testing script with step-by-step instructions has been provided (see Outfitd-Phase8-Testing-Script.md).

- ⬜ TEST 1: Health check endpoint
- ⬜ TEST 2: Register a new account
- ⬜ TEST 3: Log in with correct password
- ⬜ TEST 4: Wrong password rate limiting (10 attempts)
- ⬜ TEST 5: Email verification flow
- ⬜ TEST 6: Google OAuth login
- ⬜ TEST 7: Guest session limits
- ⬜ TEST 8: Logout + session cleanup
- ⬜ TEST 9: Admin access control (non-admin can't access admin routes)
- ⬜ TEST 10: Store Credit calculation server-side integrity
- ⬜ TEST 11: Subscription tier enforcement
- ⬜ TEST 12: Wager escrow adversarial test (double-spend prevention)
- ⬜ TEST 13: Leaderboard distribution + Style OP integrity
- ⬜ TEST 14: Login streak + referral fraud vectors
- ⬜ TEST 15: Seller dashboard end-to-end
- ⬜ TEST 16: PayPal redemption in sandbox
- ⬜ TEST 17: Stripe test mode end-to-end
- ⬜ TEST 18: OWASP ZAP automated security scan
- ⬜ TEST 19: Rate limiting under load (Apache Bench)
- ⬜ TEST 20: Cookie consent banner verification
- ⬜ TEST 21: Onboarding flow for new users
- ⬜ TEST 22: KYC submission flow
- ⬜ TEST 23: Content-Security-Policy headers
- ⬜ TEST 24: Delete account

### Post-Testing Items
- ⬜ Apply for Microsoft PhotoDNA (then add PHOTODNA_API_KEY to Render, set CSAM_SCANNING_ENABLED=true)
- ⬜ Apple Sign In credentials
- ⬜ Set PAYPAL_MODE=live and PAYOUTS_ENABLED=true when ready for real payouts
- ⬜ Switch Stripe to live keys when ready
- ⬜ Get written legal opinion back from counsel on 1v1 wager feature
- ⬜ Rotate any exposed GitHub PATs from earlier sessions

---

## KEY ARCHITECTURAL DECISIONS

- **Revenue split:** 85% seller / 15% Outfitd on marketplace sales
- **Store Credits denomination:** 100 Store Credits = $1.00 USD
- **Minimum payout:** $10.00 (1,000 Store Credits)
- **Maximum payout:** $500.00 per transaction
- **Payout cooldown:** 24 hours between redemptions
- **Daily payout limit:** $1,000.00 total across all users
- **Guest session:** 30-minute window, 20 page views max
- **Age requirement:** 18+
- **Dispute resolution:** Arbitration-first in California
- **Return window:** 30 days for marketplace items
- **Subscription tiers:** Member (free, 5% SC) → Insider (paid, 7% SC) → Legend (paid, 10% SC)

---

## SECURITY NOTES

- Two GitHub Personal Access Tokens were exposed in earlier chat sessions — MUST be rotated
- All API keys are stored as Render environment variables (not in code)
- Frontend passed API key leak scan (grep returned no matches)
- npm audit: 0 vulnerabilities
- CSAM scanning fails closed (if API is down, images go to manual moderation queue, not published)
- PayPal payouts use optimistic locking on store_credits to prevent double-spend
- RLS enabled on all new Supabase tables
