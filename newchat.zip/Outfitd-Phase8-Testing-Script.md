# Outfitd Phase 8: Pre-Launch Security Audit — Testing Script

**Date:** April 2026
**Tester:** Wilson
**Frontend:** https://outfitd.co
**Backend:** https://outfitd-server.onrender.com
**Supabase:** Dashboard at supabase.com

---

## How to use this script

Go through each test below in order. For each test, mark PASS or FAIL. If FAIL, note the issue and fix it before moving on.

---

## TEST 1: Health Check Endpoint

**What:** Confirm the backend is responding.

1. Open Terminal
2. Run: `curl https://outfitd-server.onrender.com/health`
3. Expected result: `{"status":"ok"}`

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 2: Register a New Account

**What:** Confirm email/password registration works end-to-end.

1. Open https://outfitd.co in an incognito/private browser window
2. Click Sign Up / Register
3. Enter a test email (use a real email you can access) and a password (8+ characters)
4. Click Register
5. Check your email for a verification link
6. Click the verification link
7. Confirm you're redirected back and logged in

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 3: Log In with Correct Password

**What:** Confirm login works after registration.

1. Log out of the account you just created
2. Click Log In
3. Enter the same email and password
4. Confirm you're logged in and see your dashboard/profile

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 4: Log In with Wrong Password (10 times)

**What:** Confirm rate limiting kicks in.

1. Log out
2. Try logging in with the correct email but a WRONG password
3. Repeat 10 times rapidly
4. Expected: After several attempts, you should get a rate limit error (429 status) or lockout message
5. Verify in Sentry that the failed attempts are logged

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 5: Verify Email Flow

**What:** Confirm email verification works.

1. Register a brand new account with a different email
2. Do NOT click the verification link
3. Try to access protected features (posting, battles, etc.)
4. Expected: You should be prompted to verify your email first
5. Now click the verification link
6. Confirm the account is now fully functional

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 6: Google OAuth Login

**What:** Confirm Google Sign In works.

1. Log out
2. Click "Sign in with Google"
3. Select your Google account
4. Confirm you're redirected back and logged in
5. Check that your profile shows the correct name/email from Google

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 7: Guest Session Limits

**What:** Confirm unauthenticated users are limited.

1. Open a brand new incognito window (no cookies)
2. Browse the site WITHOUT logging in
3. Browse through products/battles/leaderboard
4. After 20 API requests, you should see a message asking you to sign up
5. Try accessing a protected action (like creating a post or battle) without logging in
6. Expected: 401 error with "Authentication required" message
7. After 30 minutes of the session starting, confirm you're prompted to create an account

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 8: Log Out and Session Cleanup

**What:** Confirm logout properly clears the session.

1. Log in to your account
2. Click Log Out
3. Confirm you're redirected to the home/login page
4. Try pressing the browser back button
5. Expected: You should NOT see your dashboard — you should be redirected to login
6. Check that cookies/localStorage are cleared (open DevTools → Application → Cookies)

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 9: Admin Access Control

**What:** Confirm non-admin users can't access admin routes.

1. Log in as a regular (non-admin) user
2. Open DevTools → Console
3. Run: `fetch('/api/admin/users').then(r => r.json()).then(console.log)`
4. Expected: 401 or 403 error — NOT a list of users
5. Try accessing any admin panel UI elements
6. Expected: They should not be visible or accessible

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 10: Store Credit Calculation Integrity

**What:** Confirm the server uses the DATABASE balance, not the client value.

1. Log in as a test user
2. Open DevTools → Console
3. Try to tamper with the client-side balance: `S.user.cashOP = 99999` (or however your frontend stores it)
4. Try to redeem Store Credits
5. Expected: The server should use the REAL balance from the database, not 99999
6. Check Supabase → users table to confirm the actual balance

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 11: Subscription Tier Enforcement

**What:** Confirm free users get free-tier rates, not premium rates.

1. Log in as a free-tier (Member) user
2. Open DevTools → Console
3. Run: `S.user.subscription = 'legend'` (try to fake Legend tier)
4. Make a purchase and check what Store Credit rate you receive
5. Expected: Server awards 5% (Member rate), NOT 10% (Legend rate)
6. Verify in Supabase that the correct rate was applied

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 12: Wager Escrow — Adversarial Test

**What:** Confirm you can't double-spend Store Credits on wagers.

1. Log in to Account A (the challenger)
2. Note your Store Credit balance
3. Create a battle challenge and stake some Store Credits
4. Before the challenge is accepted, open DevTools → Application → Local Storage
5. Try clearing localStorage to "restore" your balance on the client
6. Try creating a SECOND challenge with the same credits
7. Expected: Server rejects the second challenge — your DB balance already shows the deduction
8. Check Supabase to confirm the escrow deducted correctly

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 13: Leaderboard Distribution Integrity

**What:** Confirm the leaderboard can't be gamed via client manipulation.

1. Log in to a test account
2. Open DevTools → Console
3. Run: `S.user.op = 999999999` (try to fake Style Points/OP)
4. Check the leaderboard
5. Expected: Your position should NOT change — the leaderboard pulls from the database
6. Verify in Supabase that your actual OP value is unchanged

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 14: Login Streak & Referral Fraud Vectors

**What:** Confirm login streaks and referral codes can't be exploited.

1. Open DevTools → Console
2. Run: `S.loginStreak = 999` (try to fake streak)
3. Expected: Server ignores the client value
4. Try applying a referral code to your OWN account
5. Expected: Server rejects it
6. Try applying the same referral code twice
7. Expected: Server rejects the duplicate

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 15: Seller Dashboard End-to-End

**What:** Confirm the full seller flow works.

1. Log in as an approved seller (or create one via admin panel)
2. Create a new listing with a title, description, price, and photo
3. Confirm it appears in the admin moderation queue (log in as admin to check)
4. Approve the listing as admin
5. Confirm it now appears in the marketplace/shop
6. Log in as a different test user (buyer)
7. Purchase the item
8. Go back to the seller account → Seller Dashboard
9. Mark the order as shipped
10. Log in as buyer → request a return
11. As seller/admin → approve the return
12. Check Supabase: verify the 85/15 revenue split is correct in the database

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 16: PayPal Redemption in Sandbox

**What:** Confirm the full Store Credit → PayPal payout flow works.

**Pre-requisite:** Temporarily set `PAYOUTS_ENABLED=true` on Render for this test, then set it back to `false` when done.

1. On Render, set `PAYOUTS_ENABLED=true` and redeploy
2. Log in as a KYC-verified user with enough Store Credits (minimum $10 = 1000 SC)
3. If you don't have credits, manually add them in Supabase: update the user's `store_credits` to `1500`
4. Navigate to the wallet/redeem section
5. Enter a PayPal Sandbox email address
6. Click Redeem
7. Expected: Success message with payout amount
8. Check PayPal Sandbox dashboard — confirm the payout appears
9. Check Supabase → users table — confirm `store_credits` is now 0
10. Check Supabase → payouts table — confirm a record with status "completed"
11. Try redeeming again immediately
12. Expected: "Please wait 24 hours" cooldown message
13. **IMPORTANT:** Set `PAYOUTS_ENABLED=false` back on Render when done

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 17: Stripe Test Mode End-to-End

**What:** Confirm the full Stripe payment flow works.

1. Use Stripe test card: `4242 4242 4242 4242`, any future expiry, any CVC
2. Subscribe to the Insider plan
3. Confirm the subscription is active in your account
4. Make a marketplace purchase
5. Confirm Store Credits are awarded at the correct rate (Insider rate)
6. Enter a wager battle
7. Confirm Store Credits are escrowed
8. Redeem Store Credits (if PayPal test is enabled)
9. Check Stripe Dashboard → confirm all test transactions appear
10. Check that the database is updated correctly at every step

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 18: OWASP ZAP Security Scan

**What:** Run an automated security scan against your staging URL.

1. Download OWASP ZAP from https://www.zaproxy.org (free)
2. Open ZAP
3. Click "Automated Scan"
4. Enter your backend URL: `https://outfitd-server.onrender.com`
5. Click "Attack"
6. Wait for the scan to complete (may take 15-30 minutes)
7. Review results — fix all HIGH and MEDIUM severity findings
8. Pay special attention to: AI proxy endpoints, wager endpoints, redemption endpoint

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 19: Rate Limiting Under Load

**What:** Confirm rate limiting works under pressure.

1. Open Terminal
2. Run: `ab -n 200 -c 20 https://outfitd-server.onrender.com/health`
   (If `ab` is not installed, it comes with macOS by default — Apache Bench)
3. Expected: You should see 429 (Too Many Requests) responses after hitting the limit
4. Also test the auth endpoint: `ab -n 50 -c 10 https://outfitd-server.onrender.com/api/auth/login`
5. Expected: Rate limit kicks in faster (max 20 per 15 minutes)
6. Test the AI proxy endpoint if you have one

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 20: Cookie Consent Banner

**What:** Confirm cookie consent works correctly.

1. Clear all localStorage and cookies for outfitd.co (DevTools → Application → Clear)
2. Reload the site
3. Expected: Cookie consent banner appears
4. Click "Decline" — confirm NO analytics or tracking cookies are set
5. Clear again, reload
6. Click "Accept" — confirm the consent is recorded and banner doesn't reappear
7. Test on mobile (or use DevTools responsive mode)

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 21: Onboarding Flow for New Users

**What:** Confirm the new user experience works smoothly.

1. Create a completely fresh account
2. Expected: Onboarding sequence starts (style quiz, preferences, app intro)
3. Complete all steps of the onboarding
4. Confirm data is saved correctly (check your profile reflects your choices)
5. Confirm the onboarding can be completed and dismissed
6. Confirm it does NOT show again on next login

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 22: KYC Submission Flow

**What:** Confirm the KYC verification flow works.

1. Log in as a user who has NOT submitted KYC
2. Navigate to seller settings or wallet redemption
3. Expected: You see a prompt to verify your identity
4. Fill out the KYC form (name, DOB, address, upload ID photo)
5. Submit
6. Expected: "Submitted — pending review" message
7. Log in as admin
8. Go to admin panel → KYC pending
9. Review the submission — click Approve
10. Log back in as the user
11. Expected: KYC status shows "Verified"

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 23: Content-Security-Policy Headers

**What:** Confirm CSP is set correctly for production.

1. Open https://outfitd.co
2. Open DevTools → Network tab
3. Click on the main document request
4. Check Response Headers for `Content-Security-Policy`
5. Confirm it includes your API domain in `connect-src`
6. Confirm it includes Stripe, PayPal, Google OAuth, Apple Sign In domains
7. Open DevTools → Console
8. Check for any CSP violation errors (they show as errors in the console)
9. If there are CSP errors, note which domains need to be added

☐ PASS / ☐ FAIL — Notes: _______________

---

## TEST 24: Delete Account

**What:** Confirm users can delete their accounts.

1. Log in with a test account (one you don't need)
2. Go to Account Settings
3. Click Delete Account
4. Confirm the deletion prompt
5. Expected: Account is deleted, you're logged out
6. Try logging in with the same credentials
7. Expected: Login fails — account no longer exists

☐ PASS / ☐ FAIL — Notes: _______________

---

## Summary Scorecard

| Test | Status | Notes |
|------|--------|-------|
| 1. Health Check | ☐ | |
| 2. Register | ☐ | |
| 3. Login | ☐ | |
| 4. Wrong Password / Rate Limit | ☐ | |
| 5. Email Verification | ☐ | |
| 6. Google OAuth | ☐ | |
| 7. Guest Session Limits | ☐ | |
| 8. Logout / Session Cleanup | ☐ | |
| 9. Admin Access Control | ☐ | |
| 10. Store Credit Integrity | ☐ | |
| 11. Subscription Enforcement | ☐ | |
| 12. Wager Escrow | ☐ | |
| 13. Leaderboard Integrity | ☐ | |
| 14. Streak / Referral Fraud | ☐ | |
| 15. Seller Dashboard | ☐ | |
| 16. PayPal Sandbox | ☐ | |
| 17. Stripe Test Mode | ☐ | |
| 18. OWASP ZAP Scan | ☐ | |
| 19. Rate Limiting | ☐ | |
| 20. Cookie Consent | ☐ | |
| 21. Onboarding Flow | ☐ | |
| 22. KYC Flow | ☐ | |
| 23. CSP Headers | ☐ | |
| 24. Delete Account | ☐ | |

**All 24 tests passing = ready to launch.**
